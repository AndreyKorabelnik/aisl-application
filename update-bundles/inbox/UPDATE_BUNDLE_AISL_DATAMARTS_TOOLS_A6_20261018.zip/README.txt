AISL Task 54 DataMarts Knowledge Tools A6 Update Bundle
Repository: AndreyKorabelnik/aisl-application
Exact base: 6c02a62432506baceee2666bcce468c033b15e7c
Expected output tree: d1dafafc5b600b349c0be761a4aaaf12cce625e3
Target ready branch: ready/datamarts-knowledge-tools-a6-20261018

Only seven datamarts-knowledge-tools files changed. Task46, Task49, Framework and Inventory untouched.
Changes: get_attribute_lineage reuses accepted Task46 exact TSA field mapping, with compact/paged SQL target lineage. get_evidence can inspect Task46 complete provenance, Task49 declared relation records, and paged SQL evidence; seven tools remain in one catalog.
Tests: 31/31 DataMarts, 17/17 Task49, 14/14 Task46 PASS (62/62 total); installed A6 wheel and CLI smoke PASS; independent published UCP/TSA Country replica 14/14 logical relationships PASS.
Not claimed: live GLM provider E2E (provider not available); Task34 Discovery HTTP search (not yet integrated); full cross-product dependency completeness.
Upload EXACT this ZIP as a single new file in `transport/update-bundle` branch, under `update-bundles/inbox/`, then Commit. GitHub Actions will create ready branch after checks.
