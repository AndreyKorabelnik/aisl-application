Task 26 bounded human CSV presentation change.

Changes:
- analyst-facing 9-column CSV contract;
- producer/crossing/consumer attribute ordering;
- consumer_attribute is the first proven local attribute after crossing;
- Russian human gap labels while preserving machine gap codes in full_attribute_path;
- README and targeted tests updated.

Canonical interaction-lineage JSON is unchanged. No new lineage claim is created by this patch.
Package version remains 0.1.0a3 because this is a FAST ITERATION, not a checkpoint/release bump.
