Task 51 verified GitHub Update Bundle — aisl-application

Repository: AndreyKorabelnik/aisl-application
Base: main @ f6598f490d198a09e911a6ef3a502ddb2a169dcb
Base tree: d6ac9e79c018d2fc5e930d3b29ff109aba888e03
Expected resulting tree: 7b96872595854b333c1fa19c74bdcf8ae6cc8c0a
Ready branch: ready/task51-v5-fast-check-20261010

Scope: Interaction Lineage adaptation to candidate-preserving Topology v5,
correct CLI error output, batch reuse of pinned AISL API read results,
cheap prerequisite `check` and opt-in `check --deep`.
`prepare` and `build` remain detailed; no source acquisition is requested by `build`.

Acceptance: mock 154 candidate replay 2,243 -> 62 AISL calls (cheap check);
deep check remains output-equivalent. Package tests 83 PASS, 5 pre-existing
semantic anchor selection FAIL; not an all-green production acceptance.
This ZIP is transport-only, not a release or source artifact.

Publication: upload this ZIP as a single new file into
  transport/update-bundle:update-bundles/inbox/
Commit that change to trigger `Apply Update Bundle`; verify workflow
success and exact READY_TREE; then PR ready branch into main and merge.
Do NOT copy/commit this ZIP to main.
