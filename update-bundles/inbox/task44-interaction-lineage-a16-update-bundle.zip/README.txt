Task 44 Interaction Lineage architecture-alignment batch.

Scope:
- removes JavaBean getX/isX inference from consumer-side anchor resolution;
- keeps only unique exact published payload-owner selection;
- updates Interaction Lineage documentation to the consumer-owned cross-revision architecture;
- documents prepare as transitional until Unified AISL Discovery replaces bootstrap binding/preparation;
- corrects human CSV consumer_attribute documentation to the accepted deepest meaningful consumer semantics;
- bumps aisl-interaction-lineage to 0.1.0a16;
- adds fail-closed regression tests.

Acceptance:
- 64 PASS + same 5 pre-existing baseline FAIL; zero new failures;
- wheel build PASS with local installed build toolchain;
- clean wheel install/import PASS;
- no Framework source changes.
