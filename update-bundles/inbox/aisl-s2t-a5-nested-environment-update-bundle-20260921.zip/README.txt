AISL S2T 0.1.0a5 verified Update Bundle.

Base: aisl-application main 33699995a535e95de534b6d5c8fa6ec5382d269a.
Scope: generic nested environment placeholder composition only, plus tests/version/docs.
Upload this ZIP as-is to branch transport/update-bundle under update-bundles/inbox/.
