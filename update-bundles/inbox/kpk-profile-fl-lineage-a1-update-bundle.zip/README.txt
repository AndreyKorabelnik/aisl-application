Task 44 related side-stream: KPK -> UCP -> Profile FL bounded composition bridge.

Adds aisl-kpk-profile-fl-lineage 0.1.0a1 only.
The bridge consumes exact KPK->UCP endpoint evidence, reuses the existing
Task 46 data-model-datamart-lineage builder for UCP->TSA->Profile FL, and
confirms a cross-system row only when the full UCP semantic path matches.
No Framework source or semantics are changed.
