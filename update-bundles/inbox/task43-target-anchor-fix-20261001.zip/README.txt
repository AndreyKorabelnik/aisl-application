Task 43 bounded generic Application fix.

Uses only published AISL repository value nodes to resolve target-side anchors deterministically. Complete payload-scoped scans can prove terminal/no-field-specific-use; ambiguity and incomplete scans remain fail-closed. No corpus-specific rules.
