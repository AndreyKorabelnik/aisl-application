AISL S2T revision-backed CLI update bundle

Repository: AndreyKorabelnik/aisl-application
Base main: 3e5b4235e71d8c787bce0fc3829d9ea9c68901b9
Expected candidate tree: 12a6747f40fc48dfcdef4e5b08dcf82e40108de7
Ready branch: s2t/revision-backed-cli-a6-20260923

What changes
- aisl-s2t 0.1.0a6
- public CLI becomes:
    aisl-s2t build --system-id <SYSTEM> --revision-id <REVISION> --output s2t.csv
- AISL endpoint is infrastructure configuration via AISL_BASE_URL / AISL_TIMEOUT_SECONDS
- S2T pins the exact revision and uses aisl-sdk + sql-analysis/v1
- requires common.sql-target-resolution and common.sql-target-value-source-mapping
- automatically discovers eligible targets and reads list_sql_target_value_sources with pagination
- removes obsolete public file-fed CLI commands and their CLI tests
- audit path is generated automatically next to the CSV
- adds revision-backed adapter/CLI contract tests

Acceptance intentionally NOT performed on Profile FL or Insurance per user request.

Upload this ZIP unchanged to:
  branch: transport/update-bundle
  path:   update-bundles/inbox/
Then commit that one uploaded ZIP. The existing workflow validates base commit,
patch SHA and expected candidate tree, and creates the ready branch.
