Task 34 — Published AISL evidence priority read-side

Upload this exact ZIP to the GitHub repository AndreyKorabelnik/aisl-application,
branch transport/update-bundle, path:
update-bundles/inbox/task34-evidence-priority-20261010.zip

Commit binary ZIP unchanged. The existing Apply Update Bundle workflow
validates base commit/tree, patch checksum, patch apply, and expected tree,
then creates ready/task34-evidence-priority-20261010. Open PR from that
branch to main only after confirming READY_TREE == expected_tree_sha.

No source code bytes are transmitted through GitHub Connector file-write APIs.
The canonical application main is not modified by preparation of this ZIP.

Acceptance before upload:
- app exact base commit cf1785240e6069a1f38d7aae64593dcf8ad90374
- exact base tree 54229c33bc4521d843fcfa9bb55cea480d83ec27
- source / wheel smoke, tests 32/32 PASS
- current AISL main e33f344a, 48/48 evidence records exact API roundtrip
- Gold v0.2 observed shortlist Recall@5: 7/10 -> 10/10
- preserved ambiguous multiple Java endpoints and all original candidates
- no canonical topology or runtime proof mutation.
