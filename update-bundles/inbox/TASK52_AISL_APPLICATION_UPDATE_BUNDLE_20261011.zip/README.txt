Task 52 AISL Attribute Lineage Explorer, static offline clean delivery.
This update adds a standalone browser-only module, single reusable Python clean delivery builder, Russian installation guide, and tests.
Validated against accepted main tree. No existing application modules changed.
