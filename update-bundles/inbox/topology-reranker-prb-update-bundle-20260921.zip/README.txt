Task 24 PR-B update bundle.

Adds one new independent application directory: topology-reranker/.
No existing s2t or framework-reproducibility source is modified.
No Inventory/Topology canonical matcher source is modified.

Upload this ZIP as-is to branch transport/update-bundle under:
  update-bundles/inbox/
Then commit the upload. The permanent workflow validates base commit, patch SHA,
and exact candidate tree before creating task24/topology-reranker-prb-20260921.
