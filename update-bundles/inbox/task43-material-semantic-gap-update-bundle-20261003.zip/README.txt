Task 43 semantic-usefulness repair.

This update does not attempt mathematically complete Java value-flow reconstruction.
It surfaces a mechanically observed unresolved material external source origin as an
explicit gap/readiness blocker, reusing existing published repository-value-node evidence.
No artifact owner is guessed and Core/Framework are unchanged.
