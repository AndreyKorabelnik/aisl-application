AISL DataMarts Knowledge Tools A2 publication
Exact base: 82b8669bc5c15a199eed9712aca0504ac337810d
Verified candidate tree: cd996f7133770c78ac6575cde34a55422244fe96
Only upload this ZIP to transport/update-bundle:update-bundles/inbox. Then notify ChatGPT to complete PR/merge.
