AISL application S2T a6 VERSION sync

Upload this ZIP as-is to:
  branch: transport/update-bundle
  path: update-bundles/inbox/

This bundle changes exactly one source line:
  s2t/VERSION: 0.1.0a5 -> 0.1.0a6

Base:
  commit: 7e782df6cf985b5af81da147c5a54cd15ad8ae4d
  tree:   12a6747f40fc48dfcdef4e5b08dcf82e40108de7

Expected candidate tree:
  166c827303aa94532b76033ebd1bf5f56322e020
