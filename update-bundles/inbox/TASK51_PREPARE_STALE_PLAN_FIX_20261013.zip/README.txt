Task 51 bounded fix: invalidate previous/partially written manual bundle plan files on failed prepare.
Includes regression tests and version 0.1.0a25.
Patch is relative to accepted GitHub main commit ea290ed1d70d8cd524e23cf7085388af1fe2187f.
