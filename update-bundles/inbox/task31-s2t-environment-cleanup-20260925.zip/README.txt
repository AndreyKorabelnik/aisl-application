Verified Task 31 update bundle generated from the locally accepted candidate.
