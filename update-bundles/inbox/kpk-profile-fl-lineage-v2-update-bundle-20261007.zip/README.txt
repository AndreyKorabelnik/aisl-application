KPK/Profile FL bridge v2 consumer-composition fix.

The external application now binds the CPC/UCP crossing attribute to the final
Task43 consumer attribute of the selected KPK service output root before it may
claim KPK -> Profile FL lineage. Internal clientInfo.* crossing attributes remain
provenance only. Missing/out-of-root service egress is explicit and fail-closed.

Acceptance before publication:
- package tests: 9/9 PASS
- real frozen-evidence replay: 51 rows, 21 confirmed, 0 confirmed outside bankAcctRecs output root
- clientInfo.names.surname -> ...personName.lastName -> epk_client.last_name confirmed
- clientInfo.names.fullName -> last_name no longer confirmed; unresolved KPK egress
- clientInfo.ucpID -> epkid_2_epkid.merge_epk_id remains UCP/Profile evidence with unresolved KPK egress
- wheel aisl-kpk-profile-fl-lineage 0.1.0a2 built; installed-wheel CLI smoke PASS
