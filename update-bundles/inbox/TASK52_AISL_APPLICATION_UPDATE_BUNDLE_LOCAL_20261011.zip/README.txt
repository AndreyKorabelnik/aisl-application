Task 52 local-demo revision: add reusable localhost launcher and installation documentation.
Patch based on exact accepted aisl-application main. Checked by independent clean-base replay.
Not yet pushed to GitHub; use only the approved Update Bundle workflow.
