AISL Application Update Bundle

Purpose:
Add the new consumer-owned deterministic S2T application at repository root `s2t/`.

Scope:
- environment policy v1
- explicit environment wins
- otherwise default_environment=production
- PA/deployment/non-production only with explicit context
- audit provenance
- fail-closed ambiguity
- CLI, examples, packaging and tests

Boundary:
This application belongs to AndreyKorabelnik/aisl-application.
It does not modify AISL Framework Core/KLC.

Acceptance before publication:
- 12/12 unit tests PASS
- wheel build PASS
- CLI smoke PASS
- no Insurance-specific environment index or naming heuristic
