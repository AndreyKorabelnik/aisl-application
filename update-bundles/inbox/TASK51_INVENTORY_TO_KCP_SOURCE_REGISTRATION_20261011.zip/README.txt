Task51 bounded Inventory-to-KCP registration. Upload this single ZIP to update-bundles/inbox/ on repository transport/update-bundle branch.
