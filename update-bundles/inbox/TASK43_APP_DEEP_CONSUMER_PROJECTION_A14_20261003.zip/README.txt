Task 43 deep consumer semantic projection (a14)

Purpose:
- fix generic interaction-lineage CSV projection so consumer_attribute is the deepest mechanically proven meaningful downstream semantic attribute, not the first consumer occurrence;
- preserve the full observed semantic nesting chain in full_attribute_path;
- permit projection across a missing intermediate presentation node when a deeper observed structural suffix is mechanically present;
- keep ambiguity fail-closed and prevent Java collection implementation classes from becoming semantic consumer names.

Scope:
- Application only; Framework/Core/KLC unchanged.
- No UCP/RSC/birthDate-specific production rule.

Acceptance:
- full test suite: 61 PASS / same 5 pre-existing FAIL as a13; no new failure names;
- edge 1 production build: 46/46 crossings resolved, material semantic gaps=0; exactly 6 rows changed vs a13;
- edge 2 production build: 46/46 crossings resolved, material semantic gaps=0; exactly 6 rows changed vs a13;
- final aggregate: 141 rows / 9 columns;
- birthDate edge 1 consumer_attribute = bankAcctRecs[].cardAcctId.custInfo.personInfo.birthday;
- birthDate edge 2 consumer_attribute = ProxyBankAcctRec.cardAcctId.custInfo.personInfo.birthday.
