AISL Application Update Bundle

Adds the bounded external consumer `aisl-ucp-tsa-replica-er`.

Purpose:
- project published UCP declared relationships onto exact TSA replica tables;
- map UCP-declared identity fields to exact TSA replica columns;
- expose explicit gaps when identity mapping is absent;
- never claim a physical database PRIMARY KEY, FOREIGN KEY, or JOIN condition without published evidence.

Acceptance before freeze:
- local unit tests: 10/10 PASS;
- real public Knowledge API E2E, UCP rev-c39ad2888fc29779cf411bd9 + TSA rev-5a16127953b6774b18dd8268:
  - 322 unique replica tables;
  - 555 unique projected relationships;
  - 321/322 confirmed declared-identity -> replica-column mappings;
  - 1 explicit TSA identity-field mapping gap (OmniMemoryIndividualFacts.id);
  - 0 entity-mapping gaps;
  - physical DB PK/FK/JOIN remains not_observed rather than guessed;
- bounded Individual closure: 101 tables, 157 relationships, 101/101 confirmed identity mappings.
