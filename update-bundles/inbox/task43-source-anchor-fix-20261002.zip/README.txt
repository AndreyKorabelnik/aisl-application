Task 43 final blind acceptance — generic source-side published-anchor resolution.

The patch is based on the exact accepted aisl-application main identity recorded in UPDATE_MANIFEST.json.
It adds a fail-closed source-side fallback that selects only a unique field node belonging to an exact typed payload instance in the same published operation. No repository/corpus-specific rules are introduced.

Acceptance evidence before publication:
- edge repository_edge_63231684be7dcbc579868f81: 15/15 crossing resolved, gap_count=0;
- source_local_anchor_gap_count=0, target_local_anchor_gap_count=0;
- build created zero KCP producer jobs;
- new source/target fallback regression file: 9/9 PASS;
- full interaction-lineage suite: 31 PASS / 5 pre-existing FAIL versus exact merged main 27 PASS / same 5 FAIL.
