Task 43 BASE_MOVED follow-up after PR #34.

Purpose:
- preserve the already-merged deepest-consumer projection;
- when several technical collection aliases carry the same nested payload,
  converge only through an independently published exact typed catalog milestone;
- do not choose an alias arbitrarily and do not invent a semantic endpoint;
- bump aisl-interaction-lineage from 0.1.0a14 to 0.1.0a15.

Acceptance:
- full test suite: 62 passed; same 5 pre-existing baseline failures; zero new failures;
- edge 2 six-row real-corpus probe RC=0;
- documentNumber/documentSeries reach BankAcctRec.cardAcctId.custInfo.personInfo.identityCard.idNum;
- birthDate/name/patronymic/surname retain the previously accepted deepest semantic consumers;
- final aggregate remains 141 rows x 9 columns; 12 semantic consumer rows changed from the pre-deepest-consumer result; 129 unchanged.
