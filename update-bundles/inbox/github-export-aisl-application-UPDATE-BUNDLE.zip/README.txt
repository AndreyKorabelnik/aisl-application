GitHub infrastructure-only update.
Repo: AndreyKorabelnik/aisl-application
Exact base commit: 414ef054f17164263b7b3cb9aad9996d67921ff7
Base tree: f6a8c60edfb5351d353e901f3d1ccc44ac01641a
Candidate tree: d40ca58023a32caf1955c723dbfa76bf260fd0cd
Adds only .github/workflows/export-main-source.yml.
Upload this ZIP to transport/update-bundle/update-bundles/inbox/ in GitHub and Commit.
Workflow creates the ready branch; then verify PR and merge.
