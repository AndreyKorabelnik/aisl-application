Task 43 — delegate interaction-lineage preparation to the generic Framework preparation lifecycle.

Contains only interaction-lineage integration changes:
- check remains read-only and exposes mechanically observed preparation requirements from published AISL boundary facts;
- prepare calls only the public KCP POST /api/v1/preparations/run contract;
- old application-side Bitbucket production/job/bundle/import orchestration is removed;
- missing bindings/revisions/capabilities become generic repository preparation demands, preserving initial Task 26 preparation behavior without Git mechanics in the application;
- external request/response continuation is grouped by mechanically observed client boundary identity;
- exact immutable revisions returned by Framework are pinned before post-check;
- blocked/no-progress/step-limit fail closed; repeated already-ready prepare performs no Framework work;
- build remains read-only and contains no preparation dependency.

Base: aisl-application main ad5e339b6c06c9621a8cba4b4dcc56a72c0361b8
Expected candidate tree: 8968aeca58804e402265066f2fe5ce8c23ac163d
