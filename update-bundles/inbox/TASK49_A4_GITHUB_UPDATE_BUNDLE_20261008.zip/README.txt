Task49 A4 publication. Upload this zip unchanged as a single new file to transport/update-bundle: update-bundles/inbox/task49-replica-fields-a4-20261008.zip
Source base: 4f3174d453dd160a3371501552c4db78adb51d58
Expected tree: 213426952e3f37092d78854cfda7386467f7b36f
