Task 49 A3 Update Bundle

Bounded consumer-projection change:
- add --keys-csv with logical primary-key projection per replica table;
- make --links-csv represent logical relationships without misleading source identity;
- preserve physical PK/FK status as not_observed unless independently published.

Base: AndreyKorabelnik/aisl-application main f98af98db291a9eeeb73ab3b41ff45977cf3e76d
Expected candidate tree: eec5a00896e4b563d29d15e1970be69acda7615c
