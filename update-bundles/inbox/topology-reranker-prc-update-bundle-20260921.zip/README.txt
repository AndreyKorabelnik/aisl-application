Task 24 PR-C update bundle.

Extends only topology-reranker/ in aisl-application.
Adds provider-neutral external-command JSON adapter, resumable per-package batch
orchestration, and CLI entrypoint. Does not change aisl-inventory, canonical topology,
matcher/eligibility semantics, s2t, or framework-reproducibility.

Upload this ZIP as-is to branch transport/update-bundle under:
  update-bundles/inbox/
Then commit the upload. The permanent workflow validates exact base commit,
patch SHA, and expected candidate root tree before creating:
  task24/topology-reranker-prc-20260921
