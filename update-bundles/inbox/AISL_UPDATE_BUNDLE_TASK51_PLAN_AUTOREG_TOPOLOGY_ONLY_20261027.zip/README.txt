AISL Task 51 -- single combined interaction-lineage plan and selected Git auto-registration update.
Repository: AndreyKorabelnik/aisl-application
Base SHA: 4e04f57b6c96f9b870d92c85700636d086867d70
Base Git tree: e71a6886bdb45cfd303fbf004c4b24530d51bf79
Expected tree: 613a74b6c4d6285a10013c8664571b4138ea2ec1
Patch SHA-256: c7c75ecccc89f8a9623914390939ed8af4046294d845972a9d47d60d6a4864e4
Includes read-only interaction-lineage plan CLI, Nexus unknown-artifact reporting,
and bounded Topology Git source registration through KCP without --git-origin.
Use GitHub branch transport/update-bundle and update-bundles/inbox/ to apply.
Local acceptance: 132 PASS / 3 existing FAIL, no new failures.
Installed wheel CLI smoke on real Topology v5 passed; Nexus E2E not performed.
Does NOT modify Framework/KCP. Separate pending scoped Git auth Update Bundle
is needed for two independent Git credential origins.
