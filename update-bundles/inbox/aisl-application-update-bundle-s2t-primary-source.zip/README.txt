AISL Application Update Bundle

Purpose:
Add deterministic upstream-primary-source collapse to aisl-application/s2t.

Rules:
- mechanically published branch_relation_name is the primary/upstream source identity
- downstream terminal relations never replace an unresolved upstream branch
- no hist/bkp/devops/path-name heuristics
- distinct resolved value branches remain distinct
- syntactic templates resolving to the same exact source relation are deduplicated
- non-primary lookup roles are not folded into driver sources

Acceptance:
- 19/19 tests PASS
- wheel build PASS
- CLI smoke PASS
- real Insurance former downstream residuals: 11/11 resolved to the already-established upstream source
- Framework repository unchanged
