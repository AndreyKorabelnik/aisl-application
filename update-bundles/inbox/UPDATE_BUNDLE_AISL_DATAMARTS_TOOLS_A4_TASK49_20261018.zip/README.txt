AISL DataMarts Knowledge Tools 0.1.0a4 — Task 49 reuse (2026-10-18)
Verified exact base and tree identity in UPDATE_MANIFEST.json.
Contains local A3 correctness fixes plus A4 Task 49 integration.
Only datamarts-knowledge-tools/ changes. Task 49 itself remains unchanged.
Normal GitHub workflow: upload this ZIP as exactly one changed file to
  transport/update-bundle:update-bundles/inbox/
Then Apply Update Bundle must create ready/datamarts-knowledge-tools-a4-task49-20261018
at the exact expected_tree_sha. Complete publication through PR/merge/final readback.
Do not apply to a moved main. The wheel and real AISL acceptance are separate.
