Task 43 bounded Application fix.

Purpose:
- external_source_owner_unresolved with mechanically observed parent_declared_type no longer terminates inside Application;
- Application sends the observed external type as observed_boundary.observed_anchors to the existing Framework/Task42 preparation path;
- Application does not infer or name any Maven G:A owner;
- when no mechanical type anchor exists, the existing fail-closed blocked behavior is preserved.

Package version:
- aisl-interaction-lineage 0.1.0a9 -> 0.1.0a10

Acceptance:
- focused new/changed tests: 3 PASS;
- exact a9 base full interaction-lineage suite: 47 PASS / 5 pre-existing FAIL;
- candidate a10 full interaction-lineage suite: 48 PASS / same 5 FAIL;
- zero new failures;
- git diff --check PASS;
- workflow-equivalent git apply --check PASS;
- exact base tree cc25514b42eab950485c116dc219cd75e0fc0119;
- exact candidate tree cd817c129df4b33f37d5483234342c25b785f793.
