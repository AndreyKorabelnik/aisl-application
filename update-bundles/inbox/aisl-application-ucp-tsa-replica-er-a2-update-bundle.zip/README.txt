Task 49 / aisl-ucp-tsa-replica-er 0.1.0a2 update bundle.

Changes only the bounded external application:
- adds --links-csv compact replica-table links output;
- makes all output switches independently optional;
- requires at least one output;
- bumps package version to 0.1.0a2;
- updates tests and README.

Accepted projection replay on the user's Individual result:
- 157 input relationships -> 157 compact links;
- physical_join_status remains not_observed for 157/157;
- no new semantic claims are introduced.

Unit tests: 12/12 PASS.
