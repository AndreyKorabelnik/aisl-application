Bounded consumer-side KPK / UCP / TSA / Profile FL common-origin CSV refinement.

Accepted semantics:
- UCP is the common upstream origin.
- UCP -> KPK and UCP -> TSA -> Profile FL are independent downstream branches.
- A consumer row requires at least one proven downstream branch.
- ucp_endpoint_key is split into ucp_type + ucp_attribute; ucp_service remains a separate transport/repository identity.
- Partial fullName diagnostic evidence does not duplicate the proven surname branch.

Acceptance before publication:
- data-model-datamart-lineage tests: 14/14 PASS
- kpk-profile-fl-lineage tests: 12/12 PASS
- real E2E on pinned UCP/TSA/Profile FL revisions: RC=0, stderr empty
- consumer CSV: 29 rows, SHA-256 b3b424a8657fef47b8b4e5ddb8b6744ccda80f4258264d6ede68a545d1819c15
- firstName: exactly 3 rows (first_name, first_name_hash, united_person_hash)
- surname: exactly 3 rows (last_name, last_name_hash, united_person_hash)
- clientInfo.names.fullName creates zero duplicate consumer rows
- every consumer row has at least one proven downstream branch
