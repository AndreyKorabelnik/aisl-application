Task 43 edge 8 bounded Application composition repair.

Generic behavior:
- source-side published wire fields resolve only under exact route transport context and exact case-sensitive field identity;
- source-side route wire nodes must be outbound producer-side observations;
- when source payload shape is explicitly unavailable_external_declaration but topology mechanically proves exact counterpart shape, resolve terminal at the unique published payload instance only when the public repository node catalog is complete and the exact route interface/payload instance are unique;
- no synthetic producer field is created; terminal CSV producer_attribute remains blank;
- ambiguity/incomplete scans remain unresolved/fail-closed.

Version:
- aisl-interaction-lineage 0.1.0a6 -> 0.1.0a7

Acceptance:
- focused fallback suite: 18 PASS, including case/direction/route-interface negative cases.
- full Application suite: 40 PASS / 5 FAIL; exact base has the same 5 pre-existing failures, so zero new failures.
- real edge-8 exact six-field proof: request createDate/status/updateDate resolve terminal without producer field claims; response contexts/description/name resolve to the exact published wire nodes.
- previous full candidate edge-8 build was 14/14 crossings, gap_count=0; final hardening only narrowed matching and all six affected real-corpus proofs still pass.

Base commit: 61fc527de69820a4959db957bb62edeb7940c2ab
Base tree: a2f3f7cf5f9f499a2bebbe684c771d5a2b252173
Expected candidate tree: 586e7cffe489c987b214a43951072fc920c35b4d
Patch SHA-256: 43552a3833cff36652e77b214e851c63a780aa2b3d138c3b1f2a4ddb850af50e
