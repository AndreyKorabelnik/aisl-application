Task53 protected transport for AndreyKorabelnik/aisl-application
Base: f08f01a14c78f6767d979e11cbe9550400d0d00b
Ready branch: ready/task53-sql-restorer-lateral-20261015
Changed paths: sql-restorer/README.md, sql-restorer/aisl_sql_restore.py, sql-restorer/pyproject.toml, sql-restorer/tests/test_restore.py
