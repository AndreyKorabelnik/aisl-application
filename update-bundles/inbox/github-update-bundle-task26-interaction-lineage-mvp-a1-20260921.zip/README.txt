Task 26 / interaction-lineage MVP A1.

Adds only the independent `interaction-lineage/` consumer to aisl-application.
`build` consumes repository-topology/v4 plus exact pinned AISL revisions through the
public Knowledge API. It does not read Git/source repositories and does not run analysis.

Local acceptance:
- 6/6 targeted tests PASS
- compileall PASS
- wheel build PASS
- real topology /cpcGet smoke: 4 request + 11 response field paths discovered

The source-side query requests the existing AISL attribute-path resolver with
direction=reverse. That generic Framework capability is published separately so the two
source owners remain independent.
