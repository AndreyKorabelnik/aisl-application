AISL Application / Deterministic S2T a3 update bundle

Repository: AndreyKorabelnik/aisl-application
Exact base main commit: cf33fc55e3d6bb2ceebdd1c038fbade342404342
Exact base root tree: d506fcd5a0cbf52f6ce48a47434c462590cd8e8e
Expected candidate root tree: 37545a4d049cb1b5ef68a19e320bbe618ea4c063
Target output branch: output/ready-s2t-deterministic-builder-gaps-20260920

Purpose:
- add generic deterministic 26-column S2T builder;
- add typed residual/gap classification;
- derive bounded candidate sets from public SQL column-usage context without choosing a winner;
- keep Framework unchanged and keep LLM out of this batch.

Acceptance before bundle creation:
- local generic suite: 42/42 PASS;
- anti-overfit production-literal scan: PASS;
- wheel build/install/CLI/import smoke: PASS.

Upload this ZIP unchanged to update-bundles/inbox/ on branch transport/update-bundle and commit it.
The existing Apply Update Bundle workflow validates base commit, patch SHA and expected tree, then creates the output/ready branch.
