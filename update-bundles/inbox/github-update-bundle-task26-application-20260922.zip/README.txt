Task 26 application bounded fix.

Changes:
- use exact topology REST boundary references already published by AISL;
- disambiguate ambiguous wire nodes only by exact protocol/method/route/payload-role/interface-direction identity;
- remain fail-closed when exact identity is insufficient.

No fuzzy matching, rename inference, source reread, LLM lineage, or second lineage engine is introduced.
