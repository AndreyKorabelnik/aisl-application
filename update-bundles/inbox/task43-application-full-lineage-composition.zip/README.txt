Task 43 bounded aisl-application / interaction-lineage update bundle.

Base:
- repository: AndreyKorabelnik/aisl-application
- main commit: 0134d5f1760de67d3382beee1cd432d9cbcec1f2
- main tree: 586e7cffe489c987b214a43951072fc920c35b4d

Candidate:
- expected tree: 686cc115fd6820a31be4ca43e76c4b61ea7dc9c8
- interaction-lineage: 0.1.0a7 -> 0.1.0a8

Bounded generic changes:
- prefer only exact deterministic boundary anchors that have stronger published local continuation;
- preserve Framework-selected repository IDs from external preparation into read-only composition;
- expand nested transport structure from exact published source-boundary facts under an observed topology branch;
- represent structure-only descendants without field-specific value flow as terminal, not as invented flow.

Acceptance:
- current candidate suite: 45 PASS / the same 5 historical FAIL as accepted base; zero new failures;
- canonical 2026-09-21 topology, first /cpcGet edge: 46 generated row keys = 4 request + 42 response;
- Gold subset row-key comparison: 46/46 exact keys, 0 missing, 0 extra;
- final structural-terminal tweak affects only the three structure-only source gaps and follows accepted Task 28 terminal semantics;
- build remains read-only and uses Topology + pinned/public AISL knowledge; no fuzzy matching, source fallback, or repository-specific rules.
