AISL Application Update Bundle

Purpose:
Add generic consumer-owned upstream primary-source collapse to s2t/.

Anti-overfit acceptance:
- 24/24 unit and metamorphic tests PASS
- production code contains no Insurance/Profile-FL/table/stand identifiers
- selection uses only generic sql-target-source-mapping/v2 evidence: branch_relation_name, source_relation_role, target/source identities
- driver_path only; driver_candidate/enrichment are never promoted
- input order and file/workflow naming do not affect semantic source selection
- distinct resolved upstream branches remain distinct
- unresolved/ambiguous upstream identity remains fail-closed
- Profile FL independent adjudication already established the same consumer convention: upstream/primary source in T-src, lookup/terminal contribution separate
- real Insurance bounded replay: 11/11 former downstream-context residuals collapse to already-established upstream source

No Framework Core/KLC changes.
