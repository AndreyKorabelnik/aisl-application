AndreyKorabelnik/aisl-application — AISL cleanup coordinated publication, 2026-10-31
Base c80bd2e59df860f688a162859483cb7f96b0389f / tree a88e1a2feb9d1d28429e5666856b008949e2ca0f
Expected tree f82960bf24069c548d8862c9d85dcec76aa61542
Patch SHA256 e130c74ed8bd084d6df61f16eb4b7266c77971d952dfa3494bf06b0552f4ad61
Validated against exact live GitHub main, whole repository, git apply --check, independent staged replay / git write-tree.
Commit this ZIP in the repository's transport/update-bundle at update-bundles/inbox/; GitHub Actions creates the ready branch. Only then verify, PR and merge.
Real independent caller/provider pinned Server E2E remains BLOCKED_INPUTS; no claim of that PASS.
