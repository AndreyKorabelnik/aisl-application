Task 43 Application fix: consume mechanically prepared external semantic evidence without inventing cross-repository value-flow edges.

Base: aisl-application main f625561e2140fa79ed3278b5a1124e95dc8baadb / tree cd817c129df4b33f37d5483234342c25b785f793
Expected candidate tree: fc497fac984bd0e60138ce12e4ceadd1a502c239
Target package: aisl-interaction-lineage 0.1.0a11

Acceptance:
- targeted new external-evidence tests: PASS (2/2)
- full interaction-lineage suite: 50 PASS / 5 pre-existing baseline FAIL; same five failures reproduced on unchanged a10 baseline
- real-corpus clientInfo.birthDate readiness: READY on mapper-enriched revision rev-0de64d382d3445eab0eccbd9
- real-corpus build: source_material_semantic_gap_count=0; source_external_origin_link_gap_count=1
- real-corpus CSV producer_attribute=ucp.birthDate; external mapper evidence rendered; cross-repository link explicitly marked not observed
