Task 51: Task 51: integrate missing publication bundle generation into prepare
Exact accepted base 333e7de3b5f984a8e35f3e10cdaa539eab8b047c
Target tree a2db764b17671c04688ba777dee73a164d8c2c72
