Task 39 — parser-backed MapStruct value-flow update bundle.

Base: AndreyKorabelnik/aisl main @ 6e930c770b70e22cbfc0af3c0c7fd0c6f4acf14a
Expected output branch: ready/task39-mapstruct-value-flow-20260928
Expected candidate tree: b9e3f3d90c4fb72036aeac223904610fbddc6b99

The patch is bounded to code-analyzer-core:
- exact MapStruct annotation → owning JavaMethod association;
- canonical field_occurrence/field_flow_edge publication for direct parser-backed mappings;
- focused regressions and package version 0.44.23a80.

No KLC, Prepared Runtime, Knowledge API, application, Inventory, or Task 34 source change is included.
