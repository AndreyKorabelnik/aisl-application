Task 46 bounded external application.
Adds only data-model-datamart-lineage/ to aisl-application.
Framework/AISL source is not modified by this bundle.
Accepted real public-E2E: UCP Data Model -> TSA mapping -> Profile FL SQL lineage.
