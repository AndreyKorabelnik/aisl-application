KPK/UCP/TSA/Profile FL consumer projection fix. Preserves exact observed KPK crossing when final KPK egress is not proven but the Profile FL branch is proven.
