Verified GitHub Update Bundle.
Repository: AndreyKorabelnik/aisl-application
Base commit: 8bf889529fcf4bb44c494b29b1657e30268514fa
Expected tree: bfd8e2e2e3980f161657395537dbfa403bf58d84
Output branch: ready/retire-repository-topology-20260917

Upload this ZIP unchanged to update-bundles/inbox/ on branch transport/update-bundle and commit it.
The permanent workflow validates repository/base/checksum/apply/tree before creating the output branch.
