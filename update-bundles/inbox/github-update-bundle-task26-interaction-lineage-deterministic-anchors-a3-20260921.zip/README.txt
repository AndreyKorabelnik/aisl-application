Task 26 MVP-A3 application update.
Apply to AndreyKorabelnik/aisl-application main at exact base commit in UPDATE_MANIFEST.json.
This update keeps topology crossing ownership in Repository Topology and uses AISL only for repository-local continuation.
