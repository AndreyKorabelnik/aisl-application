Task 53: independent SQL restoration application. Add sql-restorer with public revision-pinned API consumer and tests.
Run from an exact accepted main commit and verify expected Git tree.
